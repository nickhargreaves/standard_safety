var macDoList = [
  
  {lat:45.86416,lng:6.62534,data:{drive:false,zip:74120,city:"MEGÈVE"}},
  {lat:47.48832,lng:-0.54378,data:{drive:true,zip:49100,city:"ANGERS"}},
  {lat:43.17459,lng:2.99269,data:{drive:true,zip:11100,city:"NARBONNE"}}
];