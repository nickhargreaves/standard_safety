<html>    
  <head> 
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <script type="text/javascript" src="jquery-1.6.1.min.js"></script>        
    <script src="http://maps.google.com/maps/api/js?sensor=false" type="text/javascript"></script>
    <script type="text/javascript" src="gmap3.min.js"></script> 
    <script type="text/javascript">
	var macDoList = [
  <?php
	$link = mysql_connect('localhost', 'root', '');
	mysql_select_db('health');
	echo mysql_error($link);
	
	$sql=mysql_query("SELECT * FROM sh_facilities WHERE Geolocation!=''");
	$markers=array();
	while($row=mysql_fetch_array($sql))
	{
	$gps=$row['Geolocation'];
	$gps=explode(', ', $gps);
	$lat = str_replace('(', '', $gps[0]);
	$lon = str_replace(')', '', $gps[1]);
	
	$markers[]= "{lat:".$lat.",lng:".$lon.",data:{drive:false,zip:74120,city:'".$row['District']."'}}";
	}
	
	echo implode(', ', $markers);
  ?>

];
	</script> 
    <style>
      #container{
        position:relative;
        height:700px;
      }
      #googleMap{
        border: 1px dashed #C0C0C0;
        width: 75%;
        height: 700px;
      }
      
      /* cluster */
      .cluster{
      	color: #FFFFFF;
      	text-align:center;
      	font-family: Verdana;
      	font-size:14px;
      	font-weight:bold;
      	text-shadow: 0 0 2px #000;
        -moz-text-shadow: 0 0 2px #000;
        -webkit-text-shadow: 0 0 2px #000;
      }
      .cluster-1{
        background: url(images/m1.png) no-repeat;
        line-height:50px;
      	width: 50px;
      	height: 40px;
      }
      .cluster-2{
        background: url(images/m2.png) no-repeat;
        line-height:53px;
      	width: 60px;
      	height: 48px;
      }
      .cluster-3{
        background: url(images/m3.png) no-repeat;
        line-height:66px;
      	width: 70px;
      	height: 56px;
      }
      
      /* infobulle */
      .infobulle{
        overflow: hidden; 
        cursor: default; 
        clear: both; 
        position: relative; 
        height: 34px; 
        padding: 0pt; 
        background-color: rgb(57, 57, 57);
        border-radius: 4px 4px; 
        -moz-border-radius: 4px 4px;
        -webkit-border-radius: 4px 4px;
        border: 1px solid #2C2C2C;
      }
      .infobulle .bg{
        font-size:1px;
        height:16px;
        border:0px;
        width:100%;
        padding: 0px;
        margin:0px;
        background-color: #5E5E5E;
      }
      .infobulle .text{
        color:#FFFFFF;
        font-family: Verdana;
        font-size:11px;
        font-weight:bold;
        line-height:25px;
        padding:4px 20px;
        text-shadow:0 -1px 0 #000000;
        white-space: nowrap;
        margin-top: -17px;
      }
      .infobulle.drive .text{
        background: url(images/drive.png) no-repeat 2px center;
        padding:4px 20px 4px 36px;
      }
      .arrow{
        position: absolute; 
        left: 45px; 
        height: 0pt; 
        width: 0pt; 
        margin-left: 0pt; 
        border-width: 10px 10px 0pt 0pt; 
        border-color: #2C2C2C transparent transparent; 
        border-style: solid;
      }
      
    </style>
    
    <script type="text/javascript">
    
      $(function(){
      
        $('#googleMap').gmap3(
          {action: 'init',
            options:{
              center:[0.452,36.75],
              zoom: 7,
              mapTypeId: google.maps.MapTypeId.TERRAIN
            }
          },
          {action: 'addMarkers',
            radius:100,
            markers: macDoList,
            clusters:{
              // This style will be used for clusters with more than 0 markers
              0: {
                content: '<div class="cluster cluster-1">CLUSTER_COUNT</div>',
                width: 53,
                height: 52
              },
              // This style will be used for clusters with more than 20 markers
              20: {
                content: '<div class="cluster cluster-2">CLUSTER_COUNT</div>',
                width: 56,
                height: 55
              },
              // This style will be used for clusters with more than 50 markers
              50: {
                content: '<div class="cluster cluster-3">CLUSTER_COUNT</div>',
                width: 66,
                height: 65
              }
            },
            marker: {
              options: {
                icon: new google.maps.MarkerImage('http://maps.gstatic.com/mapfiles/icon_green.png')
              },
              events:{  
                mouseover: function(marker, event, data){
                  $(this).gmap3(
                    { action:'clear', name:'overlay'},
                    { action:'addOverlay',
                      latLng: marker.getPosition(),
                      content:  '<div class="infobulle'+(data.drive ? ' drive' : '')+'">' +
                                  '<div class="bg"></div>' +
                                  '<div class="text">' + data.city + ' (' + data.zip + ')</div>' +
                                '</div>' +
                                '<div class="arrow"></div>',
                      offset: {
                        x:-46,
                        y:-73
                      }
                    }
                  );
                },
                mouseout: function(){
                  $(this).gmap3({action:'clear', name:'overlay'});
                }
              }
            }
          }
        );
      });
    </script>  
  </head>
    
  <body>
    <div id="googleMap"></div>
  </body>
</html>